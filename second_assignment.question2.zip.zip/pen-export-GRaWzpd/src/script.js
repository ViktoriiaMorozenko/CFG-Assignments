const programingLanguage = {
  name : "JavaScript",
  abbreviation : "JS",
  designedBy : 'Brendan Eich',
  firstAppeared : 1995,
};

const keys = Object.keys(programingLanguage);

console.log(keys);